This is python implementation of checkers game using RL

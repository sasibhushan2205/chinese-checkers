a = {
    5:2,
    3:6}
for i in a:
    print(i)